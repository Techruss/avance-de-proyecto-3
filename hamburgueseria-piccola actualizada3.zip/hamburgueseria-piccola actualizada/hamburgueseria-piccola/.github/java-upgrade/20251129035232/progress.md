# Upgrade Progress

  ### ❗ Generate Upgrade Plan [View Log](logs\1.generatePlan.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  #### Errors
  - Failed to prepare project configuration or init upgrade options: Signature validation failed for C:\Users\r-lay\.jdk\jdk-17.0.16\microsoft-jdk-17.0.16-windows-x64.zip: fetch failed. Please check the project configuration and try again.
  
  
  - ###
    ### ✅ Install JDK 17
  </details>