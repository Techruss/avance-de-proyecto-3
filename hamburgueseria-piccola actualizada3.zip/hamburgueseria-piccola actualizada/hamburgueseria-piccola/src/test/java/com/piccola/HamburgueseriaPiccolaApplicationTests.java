package com.piccola;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HamburgueseriaPiccolaApplicationTests {

	@Test
	void contextLoads() {
	}

}
