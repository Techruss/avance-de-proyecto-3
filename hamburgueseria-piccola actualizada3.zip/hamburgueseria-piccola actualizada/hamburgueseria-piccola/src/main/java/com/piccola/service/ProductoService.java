package com.piccola.service;

import com.piccola.model.Producto;
import com.piccola.repository.ProductoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Transactional
public class ProductoService {

    private final ProductoRepository productoRepository;

    public List<Producto> listarTodos() {
        return productoRepository.findAll();
    }

    public List<Producto> listarActivos() {
        return productoRepository.findByActivoTrue();
    }

    public Optional<Producto> buscarPorId(Long id) {
        return productoRepository.findById(id);
    }

    public List<Producto> buscarPorCategoria(String categoria) {
        return productoRepository.findByCategoria(categoria);
    }

    public List<Producto> buscarPorNombre(String nombre) {
        return productoRepository.findByNombreContainingIgnoreCase(nombre);
    }

    public List<Producto> listarConStockBajo() {
        return productoRepository.findByStockLessThan(10);
    }

    public Producto guardar(Producto producto) {
        return productoRepository.save(producto);
    }

    public Producto actualizar(Long id, Producto productoActualizado) {
        return productoRepository.findById(id)
                .map(producto -> {
                    producto.setNombre(productoActualizado.getNombre());
                    producto.setDescripcion(productoActualizado.getDescripcion());
                    producto.setPrecio(productoActualizado.getPrecio());
                    producto.setStock(productoActualizado.getStock());
                    producto.setCategoria(productoActualizado.getCategoria());
                    producto.setActivo(productoActualizado.getActivo());
                    return productoRepository.save(producto);
                })
                .orElseThrow(() -> new RuntimeException("Producto no encontrado con id: " + id));
    }

    public void eliminar(Long id) {
        productoRepository.deleteById(id);
    }

    public void desactivar(Long id) {
        productoRepository.findById(id)
                .ifPresent(producto -> {
                    producto.setActivo(false);
                    productoRepository.save(producto);
                });
    }

    public void activar(Long id) {
        productoRepository.findById(id)
                .ifPresent(producto -> {
                    producto.setActivo(true);
                    productoRepository.save(producto);
                });
    }

    public void reducirStock(Long id, Integer cantidad) {
        productoRepository.findById(id)
                .ifPresent(producto -> {
                    producto.reducirStock(cantidad);
                    productoRepository.save(producto);
                });
    }

    public void aumentarStock(Long id, Integer cantidad) {
        productoRepository.findById(id)
                .ifPresent(producto -> {
                    producto.aumentarStock(cantidad);
                    productoRepository.save(producto);
                });
    }
}