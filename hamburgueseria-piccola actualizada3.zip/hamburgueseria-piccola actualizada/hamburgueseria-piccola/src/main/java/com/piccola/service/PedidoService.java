package com.piccola.service;

import com.piccola.model.Cliente;
import com.piccola.model.DetallePedido;
import com.piccola.model.Pedido;
import com.piccola.model.Pedido.EstadoPedido;
import com.piccola.model.Producto;
import com.piccola.repository.PedidoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Transactional
public class PedidoService {

    private final PedidoRepository pedidoRepository;
    private final ProductoService productoService;
    private final ClienteService clienteService;

    public List<Pedido> listarTodos() {
        return pedidoRepository.findAllByOrderByFechaDesc();
    }

    public Optional<Pedido> buscarPorId(Long id) {
        return pedidoRepository.findById(id);
    }

    public List<Pedido> listarPorEstado(EstadoPedido estado) {
        return pedidoRepository.findByEstadoOrderByFechaDesc(estado);
    }

    public List<Pedido> listarPorCliente(Long clienteId) {
        return pedidoRepository.findByClienteId(clienteId);
    }

    public List<Pedido> listarPorFechas(LocalDateTime inicio, LocalDateTime fin) {
        return pedidoRepository.findByFechaBetween(inicio, fin);
    }

    public Pedido crearPedido(Long clienteId, List<DetallePedido> detalles, String metodoPago, String observaciones) {
        Cliente cliente = clienteService.buscarPorId(clienteId)
                .orElseThrow(() -> new RuntimeException("Cliente no encontrado"));

        Pedido pedido = new Pedido();
        pedido.setCliente(cliente);
        pedido.setFecha(LocalDateTime.now());
        pedido.setEstado(EstadoPedido.PENDIENTE);
        pedido.setMetodoPago(metodoPago);
        pedido.setObservaciones(observaciones);

        for (DetallePedido detalle : detalles) {
            Producto producto = productoService.buscarPorId(detalle.getProducto().getId())
                    .orElseThrow(() -> new RuntimeException("Producto no encontrado"));

            if (producto.getStock() < detalle.getCantidad()) {
                throw new RuntimeException("Stock insuficiente para: " + producto.getNombre());
            }

            productoService.reducirStock(producto.getId(), detalle.getCantidad());

            detalle.setProducto(producto);
            detalle.setPrecioUnitario(producto.getPrecio());
            detalle.calcularSubtotal();

            pedido.agregarDetalle(detalle);
        }

        return pedidoRepository.save(pedido);
    }

    public Pedido cambiarEstado(Long id, EstadoPedido nuevoEstado) {
        return pedidoRepository.findById(id)
                .map(pedido -> {
                    pedido.cambiarEstado(nuevoEstado);
                    return pedidoRepository.save(pedido);
                })
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado con id: " + id));
    }

    public void cancelarPedido(Long id) {
        pedidoRepository.findById(id)
                .ifPresent(pedido -> {
                    for (DetallePedido detalle : pedido.getDetalles()) {
                        productoService.aumentarStock(
                                detalle.getProducto().getId(),
                                detalle.getCantidad()
                        );
                    }
                    pedido.cambiarEstado(EstadoPedido.CANCELADO);
                    pedidoRepository.save(pedido);
                });
    }

    public void eliminar(Long id) {
        pedidoRepository.deleteById(id);
    }

    public BigDecimal calcularTotalVentas(LocalDateTime inicio, LocalDateTime fin) {
        List<Pedido> pedidos = pedidoRepository.findByFechaBetween(inicio, fin);
        return pedidos.stream()
                .filter(p -> p.getEstado() == EstadoPedido.COMPLETADO)
                .map(Pedido::getTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    public long contarPedidosPorEstado(EstadoPedido estado) {
        return pedidoRepository.findByEstado(estado).size();
    }
}