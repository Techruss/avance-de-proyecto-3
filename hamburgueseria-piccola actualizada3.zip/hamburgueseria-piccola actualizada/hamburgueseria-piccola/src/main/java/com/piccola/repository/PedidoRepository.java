package com.piccola.repository;

import com.piccola.model.Pedido;
import com.piccola.model.Pedido.EstadoPedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface PedidoRepository extends JpaRepository<Pedido, Long> {

    List<Pedido> findByEstado(EstadoPedido estado);

    List<Pedido> findByClienteId(Long clienteId);

    List<Pedido> findByFechaBetween(LocalDateTime inicio, LocalDateTime fin);

    List<Pedido> findByEstadoOrderByFechaDesc(EstadoPedido estado);

    List<Pedido> findAllByOrderByFechaDesc();
}