package com.piccola.controller;

import com.piccola.service.ClienteService;
import com.piccola.service.PedidoService;
import com.piccola.service.ProductoService;
import com.piccola.model.Pedido.EstadoPedido;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.time.LocalDateTime;

@Controller
@RequiredArgsConstructor
public class HomeController {

    private final ProductoService productoService;
    private final ClienteService clienteService;
    private final PedidoService pedidoService;

    @GetMapping("/")
    public String home(Model model) {
        // Estadísticas para el dashboard
        model.addAttribute("totalProductos", productoService.listarTodos().size());
        model.addAttribute("totalClientes", clienteService.listarTodos().size());
        model.addAttribute("pedidosPendientes", pedidoService.contarPedidosPorEstado(EstadoPedido.PENDIENTE));
        model.addAttribute("pedidosEnPreparacion", pedidoService.contarPedidosPorEstado(EstadoPedido.EN_PREPARACION));

        // Productos con stock bajo
        model.addAttribute("productosStockBajo", productoService.listarConStockBajo());

        // Pedidos recientes
        model.addAttribute("pedidosRecientes", pedidoService.listarTodos().stream().limit(5).toList());

        return "index";
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        return home(model);
    }
}