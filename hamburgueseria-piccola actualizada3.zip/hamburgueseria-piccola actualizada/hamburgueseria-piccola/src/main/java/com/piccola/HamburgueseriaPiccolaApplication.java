package com.piccola;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HamburgueseriaPiccolaApplication {

	public static void main(String[] args) {
		SpringApplication.run(HamburgueseriaPiccolaApplication.class, args);
	}

}
