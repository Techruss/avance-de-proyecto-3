package com.piccola.controller;

import com.piccola.model.DetallePedido;
import com.piccola.model.Pedido;
import com.piccola.model.Pedido.EstadoPedido;
import com.piccola.service.ClienteService;
import com.piccola.service.PedidoService;
import com.piccola.service.ProductoService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/pedidos")
@RequiredArgsConstructor
public class PedidoController {

    private final PedidoService pedidoService;
    private final ClienteService clienteService;
    private final ProductoService productoService;

    // --------------------------------------------
    // LISTAR PEDIDOS
    // --------------------------------------------
    @GetMapping
    public String listar(Model model) {
        model.addAttribute("pedidos", pedidoService.listarTodos());
        return "pedidos/lista";
    }

    // --------------------------------------------
    // NUEVO PEDIDO (FORMULARIO)
    // --------------------------------------------
    @GetMapping("/nuevo")
    public String mostrarFormularioNuevo(Model model) {
        model.addAttribute("clientes", clienteService.listarTodos());
        model.addAttribute("productos", productoService.listarActivos());
        return "pedidos/formulario";
    }

    // --------------------------------------------
    // VER PEDIDO (SIN DETALLE.HTML → devuelve la lista)
    // --------------------------------------------
    @GetMapping("/{id}")
    public String ver(@PathVariable Long id, Model model) {
        Pedido pedido = pedidoService.buscarPorId(id)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));

        model.addAttribute("pedido", pedido);
        return "pedidos/lista"; // No existe detalle.html
    }

    // --------------------------------------------
    // LISTAR POR ESTADO
    // --------------------------------------------
    @GetMapping("/estado/{estado}")
    public String listarPorEstado(@PathVariable String estado, Model model) {
        EstadoPedido estadoPedido = EstadoPedido.valueOf(estado.toUpperCase());
        model.addAttribute("pedidos", pedidoService.listarPorEstado(estadoPedido));
        model.addAttribute("estado", estadoPedido);
        return "pedidos/lista";
    }

    // --------------------------------------------
    // CAMBIAR ESTADO (POR FORMULARIO BUTTON)
    // --------------------------------------------
    @PostMapping("/cambiar-estado/{id}")
    public String cambiarEstado(@PathVariable Long id, @RequestParam String estado) {
        EstadoPedido nuevoEstado = EstadoPedido.valueOf(estado.toUpperCase());
        pedidoService.cambiarEstado(id, nuevoEstado);
        return "redirect:/pedidos"; // NO redirigir a detalle inexistente
    }

    // --------------------------------------------
    // CAMBIAR ESTADO (POR URL)
    // --------------------------------------------
    @GetMapping("/cambiar-estado/{id}/{estado}")
    public String cambiarEstadoPorUrl(@PathVariable Long id, @PathVariable String estado) {
        EstadoPedido nuevoEstado = EstadoPedido.valueOf(estado.toUpperCase());
        pedidoService.cambiarEstado(id, nuevoEstado);
        return "redirect:/pedidos"; // Corregido
    }

    // --------------------------------------------
    // CANCELAR PEDIDO
    // --------------------------------------------
    @GetMapping("/cancelar/{id}")
    public String cancelar(@PathVariable Long id) {
        pedidoService.cancelarPedido(id);
        return "redirect:/pedidos"; // Corregido
    }

    // ============================================================
    //                        API REST
    // ============================================================

    @GetMapping("/api")
    @ResponseBody
    public ResponseEntity<List<Pedido>> listarApi() {
        return ResponseEntity.ok(pedidoService.listarTodos());
    }

    @GetMapping("/api/{id}")
    @ResponseBody
    public ResponseEntity<Pedido> buscarPorIdApi(@PathVariable Long id) {
        return pedidoService.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/api")
    @ResponseBody
    public ResponseEntity<Pedido> crearPedidoApi(@RequestBody Map<String, Object> pedidoData) {
        try {

            Long clienteId = Long.valueOf(pedidoData.get("clienteId").toString());
            String metodoPago = pedidoData.get("metodoPago").toString();
            String observaciones = pedidoData.getOrDefault("observaciones", "").toString();

            @SuppressWarnings("unchecked")
            List<Map<String, Object>> detallesData = (List<Map<String, Object>>) pedidoData.get("detalles");

            List<DetallePedido> detalles = new ArrayList<>();
            for (Map<String, Object> detalleData : detallesData) {
                Long productoId = Long.valueOf(detalleData.get("productoId").toString());
                Integer cantidad = Integer.valueOf(detalleData.get("cantidad").toString());

                DetallePedido detalle = new DetallePedido();
                detalle.setProducto(productoService.buscarPorId(productoId).orElseThrow());
                detalle.setCantidad(cantidad);

                detalles.add(detalle);
            }

            Pedido pedido = pedidoService.crearPedido(clienteId, detalles, metodoPago, observaciones);
            return ResponseEntity.status(HttpStatus.CREATED).body(pedido);

        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @PutMapping("/api/{id}/estado")
    @ResponseBody
    public ResponseEntity<Pedido> cambiarEstadoApi(@PathVariable Long id, @RequestBody Map<String, String> body) {
        String estado = body.get("estado");
        EstadoPedido nuevoEstado = EstadoPedido.valueOf(estado.toUpperCase());
        return ResponseEntity.ok(pedidoService.cambiarEstado(id, nuevoEstado));
    }

    @DeleteMapping("/api/{id}")
    @ResponseBody
    public ResponseEntity<Void> cancelarApi(@PathVariable Long id) {
        pedidoService.cancelarPedido(id);
        return ResponseEntity.noContent().build();
    }

    // --------------------------------------------
    // FORMULARIO HTML (CREAR PEDIDO)
    // --------------------------------------------
    @PostMapping("/guardar")
    public String guardarPedido(
            @RequestParam(name = "productoIds") List<Long> productoIds,
            @RequestParam(name = "cantidades") List<Integer> cantidades,
            @RequestParam(name = "cliente.id", required = false) Long clienteId,
            @RequestParam(name = "metodoPago") String metodoPago,
            @RequestParam(name = "observaciones", required = false) String observaciones
    ) {

        List<DetallePedido> detalles = new ArrayList<>();

        for (int i = 0; i < productoIds.size(); i++) {
            DetallePedido detalle = new DetallePedido();
            detalle.setProducto(productoService.buscarPorId(productoIds.get(i))
                    .orElseThrow(() -> new RuntimeException("Producto no encontrado")));
            detalle.setCantidad(cantidades.get(i));

            detalles.add(detalle);
        }

        pedidoService.crearPedido(clienteId, detalles, metodoPago, observaciones);

        return "redirect:/pedidos"; // Redirección correcta
    }
}
